[LN,LT]=meshgrid(lon,lat(141:181));
m_proj('miller','lon',[120 190],'lat',[10 20]);
m_coast('patch',[.8 .8 .8]);
m_grid('xtick',10,'box','fancy','tickdir','out')

msl1=msl(169,:,11)
[x y]=min(msl1)
[x1 y1]=max(sst(169,(y-10:y+10),11))
[x2 y2]=min(tp(169,(y-10:y+10),11))
hold on
lona1=y1*0.25+y-10*0.25
lona2=y2*0.25+y-10*0.25
lona=y
lata=13.1
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)
m_scatter(lona2,lata,'*')

%% 
msl1=msl(166,:,12)
[x y]=min(msl1)
[x1 y1]=max(sst(166,(y-10:y+10),12))
[x2 y2]=min(tp(166,(y-10:y+10),12))
lona2=y2*0.25+y-10*0.25
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=13.8
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)
m_scatter(lona2,lata,'*')

msl1=msl(161,:,13)
[x y]=min(msl1)
[x1 y1]=max(sst(161,(y-10:y+10),13))
[x2 y2]=min(tp(161,(y-10:y+10),13))
lona2=y2*0.25+y-10*0.25
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=15.1
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)
m_scatter(lona2,lata,'*')

msl1=msl(156,:,14)
[x y]=min(msl1)
[x1 y1]=max(sst(156,(y-10:y+10),14))
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=16.2
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)

msl1=msl(153,:,15)
[x y]=min(msl1)
[x1 y1]=max(sst(153,(y-10:y+10),15))
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=17.1
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)

msl1=msl(149,:,16)
[x y]=min(msl1)
[x1 y1]=max(sst(149,(y-10:y+10),16))
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=18
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)

msl1=msl(147,:,17)
[x y]=min(msl1)
[x1 y1]=max(sst(147,(y-10:y+10),17))
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=18.6
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)


msl1=msl(145,:,18)
[x y]=min(msl1)
[x1 y1]=max(sst(145,(y-10:y+10),18))
lona1=y1*0.25+y-10*0.25
hold on
lona=y
lata=19
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)
m_scatter(lona1,lata)

title('Track of maximum SST and minimum MSL')