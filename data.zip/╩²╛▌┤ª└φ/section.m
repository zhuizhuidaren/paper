clc
%����ͼ
a=80*1.852/(111*cos(18.6/180*pi))
b=152
c1=a+b
d=152
c2=b-a
subplot(4,1,1)
plot(lon,msl(147,:,17))
hold on
set(gca,'XTick',min(lon):5:max(lon))
hold on
plot([d,d],[min(msl(147,:,17)),max(msl(147,:,17))])
plot([c1,c1],[min(msl(147,:,17)),max(msl(147,:,17))])
plot([c2,c2],[min(msl(147,:,17)),max(msl(147,:,17))])
xlabel('��E')
ylabel('hPa')
title('Mean Sea Level Pressure')
hold on
subplot(4,1,2)
%tp1=tp*1000
hold on
plot(lon,tp1(147,:,17))
set(gca,'XTick',min(lon):5:max(lon))
plot([d,d],[min(tp1(147,:,17)),max(tp1(147,:,17))])
plot([c1,c1],[min(tp1(147,:,17)),max(tp1(147,:,17))])
plot([c2,c2],[min(tp1(147,:,17)),max(tp1(147,:,17))])
xlabel('��E')
ylabel('mm')
title('Total Precipitation')
hold on
subplot(4,1,3)
hold on
plot(lon,vimd(147,:,17))
set(gca,'XTick',min(lon):5:max(lon))
plot([d,d],[min(vimd(147,:,17)),max(vimd(147,:,17))])
plot([c1,c1],[min(vimd(147,:,17)),max(vimd(147,:,17))])
plot([c2,c2],[min(vimd(147,:,17)),max(vimd(147,:,17))])
plot([min(lon),max(lon)],[0,0],'--')
xlabel('��E')
ylabel('kg m-2')
title('Vertically Integrated Moisture Divergence')
hold on
subplot(4,1,4)
hold on
%sst1=sst-273.15
plot(lon,sst1(147,:,17))
set(gca,'XTick',min(lon):5:max(lon))
plot([d,d],[min(sst1(147,:,17)),max(sst1(147,:,17))])
plot([c1,c1],[min(sst1(147,:,17)),max(sst1(147,:,17))])
plot([c2,c2],[min(sst1(147,:,17)),max(sst1(147,:,17))])
xlabel('��E')
ylabel('��')
title('Sea Surface Temprerature')