%% 
clc
file='2013.nc'
%ncdisp(file)
lon=ncread(file,'longitude',[481],[281])
lat=ncread(file,'latitude',[141],[181])
time=ncread(file,'time')
sst=ncread(file,'sst',[481 141 1],[281 181 Inf])
sst=permute(sst,[2,1,3])
tcwv=ncread(file,'tcwv',[481 141 1],[281 181 Inf])
tcwv=permute(tcwv,[2,1,3])
msl=ncread(file,'msl',[481 141 1],[281 181 Inf])
msl=permute(msl,[2,1,3])
msl=msl/100
tp=ncread(file,'tp',[481 141 1],[281 181 Inf])
tp=permute(tp,[2,1,3])
vimd=ncread(file,'vimd',[481 141 1],[281 181 Inf])
vimd=permute(vimd,[2,1,3])