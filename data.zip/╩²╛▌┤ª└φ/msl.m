[LN,LT]=meshgrid(lon,lat);
m_proj('miller','lon',[120 190],'lat',[10 55]);
hF = figure;
%create axes for pcolor and store handle
hAxesP = axes;
%set colormap for pcolor axes
axis(hAxesP,'off')
contourf =m_contourf(LN,LT,tp1(:,:,18));
colormap(hAxesP,flipud(m_colmap('Blues')));
%create color bar and set range for color
cbP = colorbar(hAxesP,'Location','west');
%caxis(hAxesP,[contourfmin contourfmax]);
%create axes for the countourm axes
%[LN,LT]=meshgrid(lon,lat);
%m_proj('miller','lon',[120 190],'lat',[10 55]);
m_coast('patch',[.8 .8 .8]);
m_grid('box','fancy','tickdir','out')
hold on
hAxesCM = axes;
%set visibility for axes to 'off' so it appears transparent
axis(hAxesCM,'on')
%set colormap for contourm axes

%plot contourm
contour = m_contour(LN,LT,msl(:,:,18));
colormap(hAxesCM,jet);
%m_grid('box','fancy','tickdir','out')
%create color bar and set range for color
cbCM = colorbar(hAxesCM,'Location','east');
%caxis(hAxesCM,[contourmin contourmax]);

hAxesCM.Visible = 'off';
P = get(hAxesP,'Position');
XLIM = get(hAxesP,'XLim');
YLIM = get(hAxesP,'YLim');
PA = get(hAxesP,'PlotBoxAspectRatio');
set(hAxesCM,'Position',P,'XLim',XLIM,'YLim',YLIM,'PlotBoxAspectRatio',PA)
linkaxes([hAxesP,hAxesCM])
hold off

%% 
%m_contourf(LN,LT,msl(:,:,34),'edgecolor','none')
%colormap([jet;flipud(m_colmap('Blues'))])
%colorbar
%freezeColors
%hold on
%m_contour(LN,LT,tcwv(:,:,34))
