for i=1:20
a(i)=b3(i,5)*1.852/(111*cos(b3(i,1)/10./180*pi))
b(i)=b3(i,3)/10.
c1(1,i)=b(i)+a(i)
end 
%% 
lon=squeeze(lon)
lat=squeeze(lat)
for i=1:20
[x1(i)]=find(lon==c1(2,i))
[y1(i)]=find(lat==b3(i,2))
end 

for i=1:20
    sstk(i)=vimd(y1(i),x1(i),i+10)
    sstk1(i)=tp(y1(i),x1(i),i+10)
end
t=b3((1:13),4)
k=sstk(1:13)
k1=sstk1(1:13)
scatter(b3(:,4),sstk(:))
%% 
[xData, yData] = prepareCurveData( t, k1 );
ft = fittype( 'poly1' );
[fitresult, gof] = fit( xData, yData, ft );
figure( 'Name', 'untitled fit 1' );
h = plot( fitresult, xData, yData );
legend( h, 'k1 vs. t', 'untitled fit 1', 'Location', 'NorthEast' );
xlabel t
ylabel k1
grid on