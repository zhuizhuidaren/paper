%% 
t=0
sst1=sst(:,:,(11:23))
for i=1:13
 k=sst1(:,:,i)
 t=t+k
end
t=t/13
for i=1:13
    k(:,:,i)=sst1(:,:,i)-t
end
%% 
[LN,LT]=meshgrid(lon,lat);
m_proj('miller','lon',[120 190],'lat',[10 55]);
m_contourf(LN,LT,k(:,:,11))
m_coast('patch',[.8 .8 .8]);
m_grid('box','fancy','tickdir','out')
colorbar
hold on
lona=152.2
lata=18.6
m_scatter(lona,lata,'filled', 'MarkerFaceColor', 'flat', 'MarkerEdgeColor', 'w','linewi',1)